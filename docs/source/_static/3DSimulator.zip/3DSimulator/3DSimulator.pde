import processing.serial.*;

Serial myPort;
float roll, pitch, yaw;

void setup() {
  size(600, 600, P3D);
  myPort = new Serial(this, "COM9", 115200);
  myPort.bufferUntil('\n');
}

void draw() {
  background(30);
  lights();

  translate(width / 2, height / 2);

  rotateX(HALF_PI);

  rotateX(radians(-pitch));
  rotateZ(radians(-yaw));
  rotateY(radians(-roll));

  drawPlane();
}

void drawPlane() {
  noStroke();

  float wingThickness = 20;

  pushMatrix();
  fill(0, 255, 0);

  beginShape(TRIANGLES);
  vertex(0, -90, wingThickness / 2);
  vertex(-70, 0, wingThickness / 2);
  vertex(60, 0, wingThickness / 2);

  vertex(0, 90, wingThickness / 2);
  vertex(-70, 0, wingThickness / 2);
  vertex(60, 0, wingThickness / 2);
  endShape();

  beginShape(TRIANGLES);
  vertex(0, -90, -wingThickness / 2);
  vertex(60, 0, -wingThickness / 2);
  vertex(-70, 0, -wingThickness / 2);

  vertex(0, 90, -wingThickness / 2);
  vertex(60, 0, -wingThickness / 2);
  vertex(-70, 0, -wingThickness / 2);
  endShape();

  beginShape(QUADS);
  vertex(-70, 0, wingThickness / 2);
  vertex(0, -90, wingThickness / 2);
  vertex(0, -90, -wingThickness / 2);
  vertex(-70, 0, -wingThickness / 2);

  vertex(-70, 0, wingThickness / 2);
  vertex(0, 90, wingThickness / 2);
  vertex(0, 90, -wingThickness / 2);
  vertex(-70, 0, -wingThickness / 2);

  vertex(0, -90, wingThickness / 2);
  vertex(60, 0, wingThickness / 2);
  vertex(60, 0, -wingThickness / 2);
  vertex(0, -90, -wingThickness / 2);

  vertex(0, 90, wingThickness / 2);
  vertex(60, 0, wingThickness / 2);
  vertex(60, 0, -wingThickness / 2);
  vertex(0, 90, -wingThickness / 2);
  endShape();
  popMatrix();

  pushMatrix();
  fill(255, 0, 0);
  box(180, 32, 32);
  popMatrix();

  pushMatrix();
  translate(100, 0, 0);
  fill(0, 120, 255);
  sphere(16);
  popMatrix();

  pushMatrix();
  translate(-70, 0, 0);
  fill(0, 150, 255);
  box(24, 60, 16);
  popMatrix();
}

void serialEvent(Serial myPort) {
  String data = myPort.readStringUntil('\n');
  if (data != null) {
    data = trim(data);
    String[] values = split(data, ',');
    if (values.length == 3) {
      try {
        roll = float(values[0]);
        pitch = float(values[1]);
        yaw = float(values[2]);
      } catch (Exception e) {
      }
    }
  }
}
