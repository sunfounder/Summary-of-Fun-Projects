#include "display.h"

// Create global OLED display object
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Initialize the display
void initDisplay() {
  // Initialize I2C interface (UNO R4 WiFi uses onboard SDA/SCL pins)
  Wire.begin();

  // Initialize the SSD1306 display
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;); // Halt if initialization fails
  }

  // Clear the display buffer and update the screen
  display.clearDisplay();
  display.display();
}

// Clear the display buffer
void clearDisplay() {
  display.clearDisplay();
}

// Push the buffer content to the screen
void updateDisplay() {
  display.display();
}

// Draw text centered horizontally at the specified y-coordinate
void drawCenteredText(const char* text, int y, int textSize) {
  display.setTextSize(textSize);
  display.setTextColor(SSD1306_WHITE);

  int16_t x1, y1;
  uint16_t w, h;
  display.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
  display.setCursor((SCREEN_WIDTH - w) / 2, y);
  display.print(text);
}

// Draw either a filled or outlined rectangle as a highlight box
void drawHighlightBox(int x, int y, int w, int h, bool inverted) {
  if (inverted) {
    display.fillRect(x, y, w, h, SSD1306_WHITE);
  } else {
    display.drawRect(x, y, w, h, SSD1306_WHITE);
  }
}
