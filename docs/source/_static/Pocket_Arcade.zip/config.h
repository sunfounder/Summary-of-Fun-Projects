#ifndef CONFIG_H
#define CONFIG_H

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <EEPROM.h>
#include <Ethnocentric_Rg_It5pt7b.h>

// Buttons pin assignments
#define PIN_BUTTON_UP     11    // Up button connected to digital pin 11
#define PIN_BUTTON_DOWN   12    // Down button connected to digital pin 12
#define PIN_BUTTON_LEFT   2     // Left button connected to digital pin 2
#define PIN_BUTTON_RIGHT  3     // Right button connected to digital pin 3

// I2C display pins (using onboard SDA/SCL on Uno R4)
#define PIN_SDA           A4    // I2C SDA pin
#define PIN_SCL           A5    // I2C SCL pin

// Display configuration
#define SCREEN_WIDTH      128   // OLED display width, in pixels
#define SCREEN_HEIGHT     64    // OLED display height, in pixels
#define OLED_RESET        -1    // Reset pin # (or -1 if sharing Arduino reset)
#define SCREEN_ADDRESS    0x3C  // I2C address for the OLED

// Game constants
#define MAX_GAMES         8
#define BUTTON_DELAY      150   // Debounce delay in milliseconds

// Game IDs
enum GameID {
  GAME_SNAKE = 0,
  GAME_TETRIS = 1,
  GAME_FLAPPY = 2,
  GAME_2048 = 3,
  GAME_BREAKOUT = 4,
  GAME_FROGGER = 5,
  GAME_HELICOPTER = 6,
  GAME_PACMAN = 7
};

// Game states
enum GameState {
  STATE_MENU,
  STATE_PLAYING,
  STATE_GAME_OVER,
  STATE_GAME_WON
};

// Global display object
extern Adafruit_SSD1306 display;

#endif // CONFIG_H
