import cv2
import mediapipe as mp
import serial
import time

# Set the serial port (change to match your Arduino's port, e.g., "COM3" or "/dev/ttyUSB0")
ser = serial.Serial('COM3', 115200, timeout=1)
time.sleep(2)  # Wait for Arduino to reboot

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False,
                       max_num_hands=1,
                       min_detection_confidence=0.7,
                       min_tracking_confidence=0.5)
mp_draw = mp.solutions.drawing_utils

# Define a function to count fingers
def count_fingers(hand_landmarks):
    finger_tips = [8, 12, 16, 20]  # Index, middle, ring, pinky
    thumb_tip = 4

    fingers = []

    # Detect thumb (assumes right hand)
    if hand_landmarks.landmark[thumb_tip].x < hand_landmarks.landmark[3].x:
        fingers.append(1)
    else:
        fingers.append(0)

    # Detect the other four fingers
    for tip in finger_tips:
        if hand_landmarks.landmark[tip].y < hand_landmarks.landmark[tip - 2].y:
            fingers.append(1)
        else:
            fingers.append(0)

    return sum(fingers)

# Open the webcam
cap = cv2.VideoCapture(0)

last_sent = None
send_delay = 1.0  # Minimum delay between sending finger counts (seconds)
last_time = time.time()

print("Gesture recognition started. Password sequence is 5-1-5")

while cap.isOpened():
    success, frame = cap.read()
    if not success:
        break

    img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(img_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            finger_count = count_fingers(hand_landmarks)

            # Send finger count with rate limiting
            if finger_count != last_sent and (time.time() - last_time) > send_delay:
                ser.write(f"{finger_count}\n".encode())
                print(f"Finger count sent: {finger_count}")
                last_sent = finger_count
                last_time = time.time()

            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

    # Display the video feed
    cv2.imshow("Gesture Recognition (Press Q to Quit)", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
ser.close()
cv2.destroyAllWindows()
